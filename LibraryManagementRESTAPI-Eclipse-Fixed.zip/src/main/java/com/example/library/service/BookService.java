package com.example.library.service;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;
import com.example.library.model.Book;


@Service
public class BookService {
    private final Map<Integer, Book> books = new ConcurrentHashMap<>();


    public Book addBook(Book book) { books.put(book.getId(), book); return book; }
    public ArrayList<Book> getAllBooks() { return new ArrayList<>(books.values()); }
    public Book getBookById(Integer id) { return books.get(id); }
    public Book updateBook(Integer id, Book updated) {
        if (!books.containsKey(id)) return null;
        updated.setId(id);
        books.put(id, updated);
        return updated;
    }
    public boolean deleteBook(Integer id) { return books.remove(id) != null; }
}
