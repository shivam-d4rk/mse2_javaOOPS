package com.example.library.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.library.model.Book;
import com.example.library.service.BookService;


@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService bookService;
    public BookController(BookService bookService) { this.bookService = bookService; }

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        if (book.getId() == null || book.getTitle() == null || book.getAuthor() == null || book.getCategory() == null || book.getAvailableCopies() == null || book.getAvailableCopies() < 0) {
            return ResponseEntity.badRequest().build();
        }
        if (bookService.getBookById(book.getId()) != null) return ResponseEntity.status(HttpStatus.CONFLICT).build();
        return ResponseEntity.status(HttpStatus.CREATED).body(bookService.addBook(book));
    }


    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() { return ResponseEntity.ok(bookService.getAllBooks()); }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Integer id) {
        Book book = bookService.getBookById(id);
        return book == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(book);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Integer id, @RequestBody Book book) {
        if (book.getTitle() == null || book.getAuthor() == null || book.getCategory() == null || book.getAvailableCopies() == null || book.getAvailableCopies() < 0) {
            return ResponseEntity.badRequest().build();
        }
        Book updated = bookService.updateBook(id, book);
        return updated == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Integer id) {
        return bookService.deleteBook(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
