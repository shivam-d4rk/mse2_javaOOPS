LIBRARY MANAGEMENT REST API - Spring Boot

Project is an in-memory CRUD REST API (records reset when application restarts; no database required).

Eclipse import:
1. Extract ZIP.
2. Eclipse: File > Import > Maven > Existing Maven Projects, choose extracted folder.
3. Finish and wait for Maven dependencies to download.
4. Run LibraryManagementApplication.java > Run As > Java Application.
5. Base URL: http://localhost:8080/api/books

Endpoints:
POST   /api/books       Add book (JSON body); 201 Created, 400 Bad Request, 409 Conflict for duplicate ID
GET    /api/books       List all books
GET    /api/books/{id}  Get book by ID; 404 if missing
PUT    /api/books/{id} Update book details (title, author, category, availableCopies); 404 if missing, 400 invalid data
DELETE /api/books/{id}  Delete book; 204 No Content or 404 if missing

Example POST/PUT JSON:
{
  "id": 1,
  "title": "Java Basics",
  "author": "A. Sharma",
  "category": "Programming",
  "availableCopies": 5
}

This project uses an in-memory ConcurrentHashMap for simple practical demonstration. It is not connected to a database.
