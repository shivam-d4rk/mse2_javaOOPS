package com.example.orders;
import java.sql.*;
import java.util.Scanner;
public class OrderManagementApp {
 private static final Scanner sc = new Scanner(System.in);
 public static void main(String[] args) {
  try (Connection con = DBConnection.getConnection()) {
   System.out.println("Connected to ecommerce_db successfully."); int choice;
   do {
    System.out.println("\n=== ORDER MANAGEMENT SYSTEM ===\n1. Insert three sample orders\n2. Retrieve orders by status (quantity > 2)\n3. Add quantity to an order\n4. Search order and update status\n5. Show total order value and delete cancelled order\n0. Exit\nEnter choice: ");
    choice=readInt();
    switch(choice){case 1->insertSampleOrders(con);case 2->retrieveOrdersByStatus(con);case 3->addQuantity(con);case 4->updateStatus(con);case 5->showValueAndDelete(con);case 0->System.out.println("Exiting...");default->System.out.println("Invalid choice.");}
   } while(choice!=0);
  } catch(SQLException e){System.out.println("Connection/database error: "+e.getMessage());}
 }
 private static void insertSampleOrders(Connection con){
  String sql="INSERT INTO Orders(order_id, customer_name, product_name, quantity, unit_price, status) VALUES (?, ?, ?, ?, ?, ?)";
  Object[][] orders={{1001,"Aman Sharma","Keyboard",3,850.0,"Pending"},{1002,"Riya Verma","Mouse",5,450.0,"Shipped"},{1003,"Rahul Singh","Monitor",2,7200.0,"Delivered"}};
  try(PreparedStatement ps=con.prepareStatement(sql)){for(Object[] o:orders){ps.setInt(1,(Integer)o[0]);ps.setString(2,(String)o[1]);ps.setString(3,(String)o[2]);ps.setInt(4,(Integer)o[3]);ps.setDouble(5,(Double)o[4]);ps.setString(6,(String)o[5]);try{ps.executeUpdate();System.out.println("Inserted order ID "+o[0]);}catch(SQLIntegrityConstraintViolationException e){System.out.println("Duplicate order ID "+o[0]+" skipped.");}}}catch(SQLException e){System.out.println("Insert error: "+e.getMessage());}
 }
 private static void retrieveOrdersByStatus(Connection con){
  System.out.print("Enter status (Pending/Shipped/Delivered/Cancelled): ");String status=sc.nextLine().trim();
  String sql="SELECT * FROM Orders WHERE status = ? AND quantity > 2 ORDER BY unit_price DESC";
  try(PreparedStatement ps=con.prepareStatement(sql)){ps.setString(1,status);try(ResultSet rs=ps.executeQuery()){boolean found=false;while(rs.next()){found=true;printOrder(rs);}if(!found)System.out.println("No matching orders found.");}}catch(SQLException e){System.out.println("Query error: "+e.getMessage());}
 }
 private static void addQuantity(Connection con){
  System.out.print("Enter order ID: ");int id=readInt();System.out.print("Enter additional quantity: ");int amount=readInt();if(amount<=0){System.out.println("Additional quantity must be greater than zero.");return;}
  String sql="UPDATE Orders SET quantity = quantity + ? WHERE order_id = ?";
  try(PreparedStatement ps=con.prepareStatement(sql)){ps.setInt(1,amount);ps.setInt(2,id);int rows=ps.executeUpdate();if(rows>0)System.out.println("Order quantity updated successfully.");else System.out.println("Order does not exist.");}catch(SQLException e){System.out.println("Update error: "+e.getMessage());}
 }
 private static void updateStatus(Connection con){
  System.out.print("Enter order ID: ");int id=readInt();String select="SELECT * FROM Orders WHERE order_id = ?";
  try(PreparedStatement ps=con.prepareStatement(select)){ps.setInt(1,id);try(ResultSet rs=ps.executeQuery()){if(!rs.next()){System.out.println("Order does not exist.");return;}System.out.println("Current order details:");printOrder(rs);}}catch(SQLException e){System.out.println("Search error: "+e.getMessage());return;}
  System.out.print("Enter new status (Pending/Shipped/Delivered/Cancelled): ");String status=normalizeStatus(sc.nextLine().trim());if(status==null){System.out.println("Invalid status. Status was not updated.");return;}
  String update="UPDATE Orders SET status = ? WHERE order_id = ?";
  try(PreparedStatement ps=con.prepareStatement(update)){ps.setString(1,status);ps.setInt(2,id);ps.executeUpdate();System.out.println("Status updated. Updated order details:");showOrder(con,id);}catch(SQLException e){System.out.println("Status update error: "+e.getMessage());}
 }
 private static String normalizeStatus(String s){if(s.equalsIgnoreCase("Pending"))return "Pending";if(s.equalsIgnoreCase("Shipped"))return "Shipped";if(s.equalsIgnoreCase("Delivered"))return "Delivered";if(s.equalsIgnoreCase("Cancelled"))return "Cancelled";return null;}
 private static void showOrder(Connection con,int id){String sql="SELECT * FROM Orders WHERE order_id = ?";try(PreparedStatement ps=con.prepareStatement(sql)){ps.setInt(1,id);try(ResultSet rs=ps.executeQuery()){if(rs.next())printOrder(rs);}}catch(SQLException e){System.out.println(e.getMessage());}}
 private static void showValueAndDelete(Connection con){
  String totalSql="SELECT COALESCE(SUM(quantity * unit_price), 0) AS total_value FROM Orders";
  try(Statement st=con.createStatement();ResultSet rs=st.executeQuery(totalSql)){if(rs.next())System.out.println("Total order value: "+rs.getDouble("total_value"));}catch(SQLException e){System.out.println("Calculation error: "+e.getMessage());return;}
  System.out.print("Enter order ID to delete (only Cancelled orders): ");int id=readInt();String deleteSql="DELETE FROM Orders WHERE order_id = ? AND status = 'Cancelled'";
  try(PreparedStatement ps=con.prepareStatement(deleteSql)){ps.setInt(1,id);int rows=ps.executeUpdate();if(rows>0)System.out.println("Cancelled order deleted successfully.");else{String checkSql="SELECT status FROM Orders WHERE order_id = ?";try(PreparedStatement check=con.prepareStatement(checkSql)){check.setInt(1,id);try(ResultSet rs=check.executeQuery()){if(!rs.next())System.out.println("Order does not exist.");else System.out.println("Order cannot be deleted because it is not Cancelled.");}}}}catch(SQLException e){System.out.println("Delete error: "+e.getMessage());}
 }
 private static void printOrder(ResultSet rs)throws SQLException{System.out.printf("ID: %d | Customer: %s | Product: %s | Quantity: %d | Unit Price: %.2f | Status: %s%n",rs.getInt("order_id"),rs.getString("customer_name"),rs.getString("product_name"),rs.getInt("quantity"),rs.getDouble("unit_price"),rs.getString("status"));}
 private static int readInt(){while(!sc.hasNextInt()){System.out.print("Enter a valid integer: ");sc.next();}int v=sc.nextInt();sc.nextLine();return v;}
}
