ORDER MANAGEMENT SYSTEM - Java JDBC + MySQL

1) Eclipse: File > Import > Maven > Existing Maven Projects; select this folder.
2) Run database/ecommerce_db.sql in MySQL Workbench to create ecommerce_db and Orders table.
3) Edit src/main/resources/db.properties. Replace CHANGE_ME with your own MySQL password.
4) Right-click project > Maven > Update Project.
5) Run OrderManagementApp.java as Java Application.

Menu: insert sample orders, status + quantity filter (quantity > 2, unit price descending), increase quantity, validate/update status, total SUM(quantity*unit_price), delete only Cancelled orders.\nThis is a plain Java JDBC console project (not Spring Boot); no Postman/Tomcat needed.
